# SpringRest-PracticeCheck
Spring Rest Practice Check - Case Study (Admin, Student, Trainer)
